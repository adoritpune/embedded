#include "define.h"
#include "structure.h"
#include "variable.h"
#include "function.h"

void TIG_process()
{
    /*
    //tfg1=0;
	//if (mmafg = 0) 
	{
		//mmafg = 1;
		//TypeDP.DPGROUP[1] = 0x00;
		iDispcurr[0] = 'T';
		iDispcurr[1] = 'I';
		iDispcurr[2] = 'G';
		//iDispvolt[0] = 'M';
		//iDispvolt[1] = 'O';
		//iDispvolt[2] = 'D';
  //    for(j=0;j<200;j++)
  //	for(i=0;i<10000;i++);
		//OCV_ON_fg = 1;
		//hotf=1;
		//Disp_updatef=1;
		//hex_to_dec_volt(VOLTAGE);
    }*/
}