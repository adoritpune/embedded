#include "define.h"
#include "structure.h"
#include "variable.h"
#include "function.h"

void MMA_process()
{        
    //tfg1=0;
	//if (mmafg = 0) 
	{
		//mmafg = 1;
		//TypeDP.DPGROUP[1] = 0x00;
		//iDispcurr[0] = 'M';
		//iDispcurr[1] = 'M';
		//iDispcurr[2] = 'A';
		//iDispvolt[0] = 'M';
		//iDispvolt[1] = 'O';
		//iDispvolt[2] = 'D';
        //Delay(2,'s');
        
        //hex_to_dec_curr(10);
		//OCV_ON_fg = 1;
		//hotf=1;
		//Disp_updatef=1;
		//hex_to_dec_volt(VOLTAGE);
    }
    
		//if(arcforcemodef == 0)
			{
                //hex_to_dec_curr(setcurrent);		//DISPLAY SET CURRENT
                //psetcurrent = setcurrent;	
				//Typedp.digitdp7	=1;
				//if(weldon == 0)
				{
					/*if(psetcurrent!= setcurrent) //|| ( Disp_updatef==1))                             
                        {
                            //hex_to_dec_curr(setcurrent);		//DISPLAY SET CURRENT
                            //psetcurrent = setcurrent;				        
                        }*/
                    /*
				    if((( pweldvoltage != VOLTAGE) && (disp_fg = 1))|| ( Disp_updatef==1))                   
							{
							   	 hex_to_dec_volt(VOLTAGE);	 //DISPLAY VOLTAGE
						    	 pweldvoltage = VOLTAGE;
							}
					disp_fg = 0;
					Disp_updatef=0;
                    */
				}
			}        
}	